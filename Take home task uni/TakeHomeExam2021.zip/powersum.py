# Name:
# Student number:

def powersum( n ):
    return -1

def main():
    print( powersum(3) )
    print( powersum(0) )
    print( powersum(-3) )

if __name__ == "__main__":
    main()