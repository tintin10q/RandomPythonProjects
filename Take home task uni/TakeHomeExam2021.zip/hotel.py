# Name:
# Student number:

from os.path import isfile

def occupied( registry, day ):
    return -1

def main():
    print( occupied( "Registry1.txt", 10 ) ) # 2
    print( occupied( "Registry1.txt", 12 ) ) # 3
    print( occupied( "Registry1.txt", 19 ) ) # 0
    print( occupied( "Registry2.txt", 9 ) ) # 6
    print( occupied( "Registry2.txt", 0 ) ) # 3
    print( occupied( "Not_exist.txt", 9 ) ) # -1

if __name__ == "__main__":
    main()