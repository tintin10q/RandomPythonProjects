# Name:
# Student number:

def mastermind( secret, trial ):
    return ""

def main():
    print( mastermind( "1234", "4321" ) ) # OOOO
    print( mastermind( "1234", "5678" ) ) #
    print( mastermind( "1234", "3524" ) ) # XOO
    print( mastermind( "1234", "7254" ) ) # XX

if __name__ == "__main__":
    main()