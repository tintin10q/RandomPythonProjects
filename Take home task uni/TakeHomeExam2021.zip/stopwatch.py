# Name:
# Student number:

def stopwatch( wlist ):
    return 0

def main():
    print( stopwatch( [10] ) ) # 10
    print( stopwatch( [10, 12, 15] ) ) # 60
    print( stopwatch( [15, 12, 10] ) ) # 60
    print( stopwatch( [15, 12, 10, 6, 24, 40] ) ) # 120
    # I commented out this last test as it is very slow with 
    # a straightforward simulation:
    # print( stopwatch( [19, 37, 101, 7, 23] ) ) # 11431483

if __name__ == "__main__":
    main()